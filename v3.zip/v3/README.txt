SENG201Project contains:
 - doc: This folder contains javadoc and class diagrams
 - The runnable jar cst122_twg23_SpaceExplorer.jar
 - gameProperties.properties - the main game properties which can be adjusted
 - Other folders of game objects and properties files describing them

Run the jar with
java -jar cst122_twg23_SpaceExplorer.jar

Dependencies: commons-io-2.6.jar

Import SENG201Project into eclipse as an existing eclipse project, .project and .classpath are included and should link commons-io-2.6.jar automatically, if not add it in the java build path in project properties. Build from here with the class Main as the main class.

Ensure the supporting folders describing game objects are in the same directory as the runnable jar or the eclipse project root folder

In gameProperties.properties change "useGUI" to false for the CLI version or true for
the GUI version of the game