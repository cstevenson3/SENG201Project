package main;

/**
 * Thrown when shield health is depleted
 * @author Cameron Stevenson
 *
 */
public class ShieldHealthDepletedException extends Exception {

}
