package main;


/**
 * Thrown if a crew member does not have the right role to perform a certain task
 * @author Cameron Stevenson
 *
 */
public class InvalidCrewRoleException extends Exception {

}
