SENG201Project contains:
 - doc: This folder contains javadoc and class diagrams
 - The runnable jar cst122_twg23_SpaceExplorer.jar
 - 

Dependencies: commons-io-2.6.jar

Import SENG201Project into eclipse as an existing eclipse project, .project and .classpath are included and should link commons-io-2.6.jar automatically, if not add it in the java build path in project properties.

Ensure the supporting folders describing game objects are in the same directory as the running jar or the eclipse project root folder

In gameProperties.properties change "useGUI" to false for the CLI version or true for
the GUI version of the game