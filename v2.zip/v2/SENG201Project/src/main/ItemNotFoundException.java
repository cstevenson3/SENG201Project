package main;

/**
 * 
 * Thrown if an item isn't found somewhere
 * @author Cameron Stevenson
 *
 */
public class ItemNotFoundException extends Exception {

}
