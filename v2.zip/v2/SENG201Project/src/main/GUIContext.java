package main;

public enum GUIContext {
	SHOULD_EXIT,
	MAIN_MENU,
	START_GAME,
	CREW_CREATION,
	LOAD_GAME,
	HELP,
	END_GAME,
	IN_GAME
}
