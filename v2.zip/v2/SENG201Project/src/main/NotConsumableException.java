package main;

/**
 * Thrown if an item cannot be consumed
 * @author Cameron Stevenson
 *
 */
public class NotConsumableException extends Exception {

}
