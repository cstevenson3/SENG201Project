package main;

/**
 * Thrown if a crew member is out of actions when requested to perform a task
 * @author Cameron Stevenson
 *
 */
public class OutOfActionsException extends Exception {

}
