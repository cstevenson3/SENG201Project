package main;

/**
 * Thrown if changing days results in ending the game
 * @author Cameron Stevenson
 *
 */
public class OutOfDaysException extends Exception {

}
